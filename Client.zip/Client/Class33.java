// Decompiled by Jad v1.5.8f. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 


final class Class33
{

	public Class33()
	{
	}

	int anInt602;
	int anInt603;
	int anInt604;
	int anInt605;
}
